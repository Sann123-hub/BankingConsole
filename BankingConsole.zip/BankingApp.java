import java.util.*;

// ---------------- Account ----------------
class Account {
    protected int accountNumber;
    protected double balance;

    public Account(int accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient balance!");
        }
    }

    public void display() {
        System.out.println("Account No: " + accountNumber + ", Balance: " + balance);
    }
}

// ---------------- Savings ----------------
class SavingsAccount extends Account {
    public SavingsAccount(int accNo, double bal) {
        super(accNo, bal);
    }
}

// ---------------- Customer (Aggregation) ----------------
class Customer {
    private int customerId;
    private String name;
    private Account account;

    public Customer(int id, String name, Account account) {
        this.customerId = id;
        this.name = name;
        this.account = account;
    }

    public int getId() {
        return customerId;
    }

    public Account getAccount() {
        return account;
    }

    public void display() {
        System.out.println("ID: " + customerId + ", Name: " + name);
        account.display();
    }
}

// ---------------- Loan Class ----------------
class Loan {
    public static double calculateEMI(double principal, double rate, int time) {
        rate = rate / (12 * 100);
        time = time * 12;
        return (principal * rate * Math.pow(1 + rate, time)) /
               (Math.pow(1 + rate, time) - 1);
    }
}

// ---------------- Bank (Association) ----------------
class Bank {
    private List<Customer> customers = new ArrayList<>();

    public void addCustomer(Customer c) {
        customers.add(c);
        System.out.println("Customer added!");
    }

    public void deleteCustomer(int id) {
        customers.removeIf(c -> c.getId() == id);
        System.out.println("Customer deleted!");
    }

    public Customer findCustomer(int id) {
        for (Customer c : customers) {
            if (c.getId() == id) return c;
        }
        return null;
    }

    public void displayAll() {
        for (Customer c : customers) {
            c.display();
            System.out.println("-------------------");
        }
    }
}

// ---------------- Main ----------------
public class BankingApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Bank bank = new Bank();

        int choice;

        do {
            System.out.println("\n1.Add Customer");
            System.out.println("2.Delete Customer");
            System.out.println("3.Deposit");
            System.out.println("4.Withdraw");
            System.out.println("5.View All");
            System.out.println("6.Loan EMI");
            System.out.println("0.Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Account No: ");
                    int acc = sc.nextInt();
                    System.out.print("Enter Balance: ");
                    double bal = sc.nextDouble();

                    bank.addCustomer(new Customer(id, name, new SavingsAccount(acc, bal)));
                    break;

                case 2:
                    System.out.print("Enter ID: ");
                    id = sc.nextInt();
                    bank.deleteCustomer(id);
                    break;

                case 3:
                    System.out.print("Enter ID: ");
                    id = sc.nextInt();
                    Customer c = bank.findCustomer(id);
                    if (c != null) {
                        System.out.print("Amount: ");
                        double amt = sc.nextDouble();
                        c.getAccount().deposit(amt);
                    }
                    break;

                case 4:
                    System.out.print("Enter ID: ");
                    id = sc.nextInt();
                    c = bank.findCustomer(id);
                    if (c != null) {
                        System.out.print("Amount: ");
                        double amt = sc.nextDouble();
                        c.getAccount().withdraw(amt);
                    }
                    break;

                case 5:
                    bank.displayAll();
                    break;

                case 6:
                    System.out.print("Enter Loan Amount: ");
                    double p = sc.nextDouble();
                    System.out.print("Interest Rate (%): ");
                    double r = sc.nextDouble();
                    System.out.print("Time (years): ");
                    int t = sc.nextInt();

                    double emi = Loan.calculateEMI(p, r, t);
                    System.out.println("Monthly EMI: " + emi);
                    break;
            }

        } while (choice != 0);

        sc.close();
    }
}